<?php

  // construccion de constantes PHP para contener las rutas de la JSP
  
  define('NOMBRE_SERVIDOR', 'itmilpaalta2');

  define('SERVIDOR', 'http://itmilpaalta2.net/preregistro/');
  //define('SERVIDOR', 'http://localhost/preregistro/');


?>