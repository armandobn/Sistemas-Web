<link rel="stylesheet" href="<?=SERVIDOR?>css/estiloExamen.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" >

<link rel="stylesheet" href="<?=SERVIDOR?>css/b4/b4.css">
<link rel="stylesheet" href="<?=SERVIDOR?>css/font_awesome/all.css">
<link rel="stylesheet" href="<?=SERVIDOR?>css/style.css">
<link rel="stylesheet" href="<?=SERVIDOR?>js/select2/css/select2.css">
<link rel="stylesheet" href="<?=SERVIDOR?>css/hover.css" media="all">
<link rel="stylesheet" href="<?=SERVIDOR?>css/data_table/data_table_bootstrap.css">
<link rel="stylesheet" href="<?=SERVIDOR?>css/data_table/data_table_jquery.css">
<link rel="stylesheet" href="<?=SERVIDOR?>css/data_table/data_table_buttons.css">
<link rel="stylesheet" href="<?=SERVIDOR?>css/data_table/data_table.css"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

<script src="<?=SERVIDOR?>js/jquery/jq.js"></script>
<script src="<?=SERVIDOR?>js/data_table/data_table_jquery.js"></script>
<script src="<?=SERVIDOR?>js/data_table/data_table_buttons.js"></script>
<script src="<?=SERVIDOR?>js/data_table/data_table_jzip.js"></script>
<script src="<?=SERVIDOR?>js/data_table/data_table_pdf_make.js"></script>
<script src="<?=SERVIDOR?>js/data_table/data_table_vfs.js"></script>
<script src="<?=SERVIDOR?>js/data_table/data_table_html_buttons.js"></script>
<script src="<?=SERVIDOR?>js/data_table/data_table_bootstrap.js"></script>
<script src="<?=SERVIDOR?>js/select2/js/select2.js"></script>
<script src="<?=SERVIDOR?>js/font_awesome/all.js"></script>
<script src="<?=SERVIDOR?>js/swal/sw.js"></script>
<script src="<?=SERVIDOR?>js/b4/b4.js"></script>